<?php
/*
Plugin Name: Auto Delete Signatures (Robust)
Description: Löscht automatisch PNG-Dateien aus einem wählbaren Verzeichnis im Upload-Ordner nach einem konfigurierbaren Zeitraum. Sendet optional Benachrichtigungen.
Version: 1.6
Author: ChatGPT
*/

defined('ABSPATH') or die('No script kiddies please!');

function cleanup_signature_files($manual = false) {
    if (!function_exists('wp_upload_dir')) return;

    $upload_dir = wp_upload_dir();
    if (!isset($upload_dir['basedir'])) return;

    $subfolder = sanitize_text_field(trim(get_option('signature_cleanup_folder', 'signature'), '/'));
    $target_dir = trailingslashit($upload_dir['basedir']) . $subfolder;

    if (!is_dir($target_dir)) return;

    $files = glob($target_dir . '/*.png');
    if (!$files) return;

    $deleted_files = array();
    $days = intval(get_option('signature_cleanup_days', 28));
    $max_age = 60 * 60 * 24 * $days;

    foreach ($files as $file) {
        if (!file_exists($file)) continue;
        $file_age = time() - filemtime($file);
        if ($file_age > $max_age || $manual) {
            if (@unlink($file)) {
                $deleted_files[] = basename($file);
            }
        }
    }

    if (!empty($deleted_files)) {
        $to = sanitize_email(get_option('signature_cleanup_email', get_option('admin_email')));
        if (is_email($to)) {
            $subject = 'Auto Delete Signatures: Dateien gelöscht';
            $message = "Folgende PNG-Dateien wurden gelöscht (älter als {$days} Tage):\n\n" . implode("\n", $deleted_files);
            wp_mail($to, $subject, $message);
        }

        update_option('signature_cleanup_log', implode("\n", $deleted_files));
        update_option('signature_cleanup_last_run', current_time('mysql'));
    }
}

function setup_signature_cleanup_cron() {
    if (!wp_next_scheduled('daily_signature_cleanup')) {
        wp_schedule_event(time(), 'daily', 'daily_signature_cleanup');
    }
}
add_action('init', 'setup_signature_cleanup_cron');
add_action('daily_signature_cleanup', 'cleanup_signature_files');

function remove_signature_cleanup_cron() {
    $timestamp = wp_next_scheduled('daily_signature_cleanup');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'daily_signature_cleanup');
    }
}
register_deactivation_hook(__FILE__, 'remove_signature_cleanup_cron');

function auto_delete_signatures_menu() {
    add_menu_page(
        'Auto Delete Signatures',
        'Signature Cleaner',
        'manage_options',
        'auto-delete-signatures-info',
        'auto_delete_signatures_info_page',
        'dashicons-trash',
        90
    );
}
add_action('admin_menu', 'auto_delete_signatures_menu');

function auto_delete_signatures_info_page() {
    if (!current_user_can('manage_options')) return;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        check_admin_referer('signature_cleanup_settings');
        if (isset($_POST['signature_cleanup_days'])) {
            update_option('signature_cleanup_days', intval($_POST['signature_cleanup_days']));
        }
        if (isset($_POST['signature_cleanup_email'])) {
            update_option('signature_cleanup_email', sanitize_email($_POST['signature_cleanup_email']));
        }
        if (isset($_POST['signature_cleanup_folder'])) {
            update_option('signature_cleanup_folder', sanitize_text_field($_POST['signature_cleanup_folder']));
        }
        if (isset($_POST['signature_cleanup_manual'])) {
            cleanup_signature_files(true);
            echo '<div class="updated"><p>Manuelle Bereinigung durchgeführt.</p></div>';
        } else {
            echo '<div class="updated"><p>Einstellungen gespeichert.</p></div>';
        }
    }

    $days = get_option('signature_cleanup_days', 28);
    $email = get_option('signature_cleanup_email', get_option('admin_email'));
    $folder = get_option('signature_cleanup_folder', 'signature');
    $last_log = get_option('signature_cleanup_log', 'Keine Einträge.');
    $last_run = get_option('signature_cleanup_last_run', 'Noch nie ausgeführt.');

    $upload_base = wp_upload_dir()['basedir'];
    $subfolders = array_filter(glob($upload_base . '/*', GLOB_ONLYDIR));

    echo '<div class="wrap">';
    echo '<h1>Signature Cleaner</h1>';
    echo '<form method="post">';
    wp_nonce_field('signature_cleanup_settings');
    echo '<p>PNG-Dateien nach <input type="number" name="signature_cleanup_days" value="' . esc_attr($days) . '" min="1" max="365"> Tagen löschen.</p>';
    echo '<p>Benachrichtigungen senden an: <input type="email" name="signature_cleanup_email" value="' . esc_attr($email) . '" size="40"></p>';
    echo '<p>Verzeichnis auswählen: <select name="signature_cleanup_folder">';
    foreach ($subfolders as $dir) {
        $name = basename($dir);
        $selected = ($name == $folder) ? 'selected' : '';
        echo "<option value="$name" $selected>$name</option>";
    }
    echo '</select></p>';
    echo '<p><input type="submit" class="button-primary" value="Speichern"></p>';
    echo '<p><input type="submit" name="signature_cleanup_manual" class="button" value="Jetzt bereinigen"></p>';
    echo '</form><hr>';
    echo '<h2>Letzter Durchlauf:</h2>';
    echo '<p>' . esc_html($last_run) . '</p>';
    echo '<h2>Zuletzt gelöschte Dateien:</h2>';
    echo '<pre>' . esc_html($last_log) . '</pre>';
    echo '</div>';
}
