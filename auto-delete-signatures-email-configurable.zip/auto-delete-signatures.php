<?php
/*
Plugin Name: Auto Delete Signatures
Description: Löscht automatisch Unterschriftenbilder aus Contact Form 7 Signature nach einem einstellbaren Zeitraum und sendet eine Benachrichtigungs-E-Mail an eine konfigurierbare Adresse.
Version: 1.4
Author: ChatGPT
*/

defined('ABSPATH') or die('No script kiddies please!');

// Cleanup-Funktion mit E-Mail und Log
function cleanup_signature_files() {
    $upload_dir = wp_upload_dir();
    $signature_dir = $upload_dir['basedir'] . '/signature/';
    
    if (!is_dir($signature_dir)) return;

    $files = glob($signature_dir . '*.png');
    $deleted_files = array();

    $days = intval(get_option('signature_cleanup_days', 28));
    $max_age = 60 * 60 * 24 * $days;

    foreach ($files as $file) {
        if (is_file($file)) {
            $file_age = time() - filemtime($file);
            if ($file_age > $max_age) {
                unlink($file);
                $deleted_files[] = basename($file);
            }
        }
    }

    if (!empty($deleted_files)) {
        $to = get_option('signature_cleanup_email', get_option('admin_email'));
        $subject = 'Auto Delete Signatures: Dateien gelöscht';
        $message = "Folgende Signaturdateien wurden automatisch gelöscht (älter als {$days} Tage):\n\n";
        $message .= implode("\n", $deleted_files);
        wp_mail($to, $subject, $message);

        update_option('signature_cleanup_log', implode("\n", $deleted_files));
        update_option('signature_cleanup_last_run', current_time('mysql'));
    }
}

// Cronjob registrieren
function setup_signature_cleanup_cron() {
    if (!wp_next_scheduled('daily_signature_cleanup')) {
        wp_schedule_event(time(), 'daily', 'daily_signature_cleanup');
    }
}
add_action('wp', 'setup_signature_cleanup_cron');
add_action('daily_signature_cleanup', 'cleanup_signature_files');

// Bei Deaktivierung Cronjob entfernen
function remove_signature_cleanup_cron() {
    $timestamp = wp_next_scheduled('daily_signature_cleanup');
    wp_unschedule_event($timestamp, 'daily_signature_cleanup');
}
register_deactivation_hook(__FILE__, 'remove_signature_cleanup_cron');

// Admin-Menüeintrag
function auto_delete_signatures_menu() {
    add_menu_page(
        'Auto Delete Signatures',
        'Signature Cleaner',
        'manage_options',
        'auto-delete-signatures-info',
        'auto_delete_signatures_info_page',
        'dashicons-trash',
        90
    );
}
add_action('admin_menu', 'auto_delete_signatures_menu');

// Admin-Seite mit Einstellungen
function auto_delete_signatures_info_page() {
    if (isset($_POST['signature_cleanup_days']) || isset($_POST['signature_cleanup_email'])) {
        check_admin_referer('signature_cleanup_settings');
        $days = intval($_POST['signature_cleanup_days']);
        $email = sanitize_email($_POST['signature_cleanup_email']);
        update_option('signature_cleanup_days', $days);
        update_option('signature_cleanup_email', $email);
        echo '<div class="updated"><p>Einstellungen gespeichert.</p></div>';
    }

    $days = get_option('signature_cleanup_days', 28);
    $email = get_option('signature_cleanup_email', get_option('admin_email'));
    $last_log = get_option('signature_cleanup_log', 'Keine Einträge.');
    $last_run = get_option('signature_cleanup_last_run', 'Noch nie ausgeführt.');

    echo '<div class="wrap">';
    echo '<h1>Signature Cleaner</h1>';
    echo '<form method="post">';
    wp_nonce_field('signature_cleanup_settings');
    echo '<p>Unterschriften nach <input type="number" name="signature_cleanup_days" value="' . esc_attr($days) . '" min="1" max="180"> Tagen löschen.</p>';
    echo '<p>Benachrichtigungen senden an: <input type="email" name="signature_cleanup_email" value="' . esc_attr($email) . '" size="40"></p>';
    echo '<p><input type="submit" class="button-primary" value="Speichern"></p>';
    echo '</form>';
    echo '<hr>';
    echo '<h2>Letzter Durchlauf:</h2>';
    echo '<p>' . esc_html($last_run) . '</p>';
    echo '<h2>Zuletzt gelöschte Dateien:</h2>';
    echo '<pre>' . esc_html($last_log) . '</pre>';
    echo '</div>';
}
